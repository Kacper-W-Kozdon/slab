from typing import Any, Dict, List, Optional, Tuple, Union

from scipy.optimize import curve_fit

from ..other.utils import A_parameter, Image_Sources_Positions, Mean_Path_T_R
from ..reflect_transmit.reflect_transmit import (
    Reflectance_Transmittance,
    Reflectance_Transmittance_rho,
    Reflectance_Transmittance_rho_t,
    Reflectance_Transmittance_t,
)


class Contini:
    def __init__(
        self,
        s: Union[int, float] = 0,
        mua: Union[int, float, None] = None,
        musp: Union[int, float, None] = None,
        n1: Union[int, float] = 0,
        n2: Union[int, float] = 0,
        anisothropy_coeff: Union[int, float, None] = 0.85,
        phantom: Optional[str] = "",
        DD: Optional[str] = "Dmus",
        m: int = 100,
        eq: str = "RTE",
    ) -> None:
        """
        The class initiating the slab model with the RTE and DE Green's functions. Source- Contini.

        :param s: The thickness of the diffusing slab in [mm]. Default: 0.
        :type s: Union[int, float]
        :param mua: Absorption coefficient of the slab in [mm^-1]. Default: None.
        :type mua: Union[int, float]
        :param musp: Reduced scattering coefficient of the slab in [mm^-1]. Default: None.
        :type musp: Union[int, float]
        :param n1: Refractive index of the external medium. Default: 0.
        :type n1: Union[int, float]
        :param n2: Refractive index of the diffusing medium (slab). Default: 0.
        :type n2: Union[int, float]
        :param anisothropy_coeff: The anisothropy coefficient g. musp = (1 - g) * mus. Default: 0.85
        :type anisothropy_coeff: Union[int, float, None]
        :param DD: Flag parameter to switch between mu = musp + mua for DD == "Dmuas" and mu = musp for DD == "Dmus" (Default).
        :type DD: str
        :param m: Number of mirror images (delta sources) in the lattice. Default: 100
        :type m: int
        :param eq: Flag parameter to switch between "RTE" and "DE" Green's functions. Default: "RTE"
        :type eq: str
        """

        self.s = s * 1e-3
        self.mua = None if not mua else mua * 1e3
        self.musp = None if not musp else musp * 1e3
        self.n1 = n1
        self.n2 = n2
        self.phantom = phantom
        self.DD = DD
        self.m = m
        self.eq = eq
        self.anisothropy_coeff = anisothropy_coeff

        self.err = 1e-6  # noqa: F841

    def __call__(
        self,
        t_rho: Union[Tuple[float, float], List[Tuple[float, float],]],
        mua: Union[int, float] = 0,
        musp: Union[int, float] = 0,
        anisothropy_coeff: Union[int, float, None] = None,
        **kwargs: Any,
    ) -> Union[Tuple[Any, ...], Tuple[List[Any], ...]]:
        """
        The call method evaluating parameters of the Contini model.

        :param t_rho: Variables of the model in the form (time, radial_coordinate).
        :type t_rho: Union[Tuple[float, float], List[Tuple[float, float]]]
        :param mua: Absorption coefficient of the slab in [mm^-1]. Default: None.
        :type mua: Union[int, float]
        :param musp: Reduced scattering coefficient of the slab in [mm^-1]. Default: None.
        :type musp: Union[int, float]
        :param anisothropy_coeff: The anisothropy coefficient g. musp = (1 - g) * mus. Default: 0.85
        :type anisothropy_coeff: Union[int, float, None]
        :param kwargs: Optional kwargs:
                       mode: available values: "approx", "sum"- controls G_function's computation method.
        :type kwargs: Any

        Returns:
        R_rho_t: time resolved reflectance mm^(-2) ps^(-1)
        T_rho_t: time resolved transmittance mm^(-2) ps^(-1)
        R_rho: reflectance mm^(-2)
        T_rho: transmittance mm^(-2)
        R_t: ps^(-1)
        T_t: ps^(-1)
        l_rho_R: mean free path (reflected) mm
        l_rho_T: mean free path (transmitted) mm
        R: to be added
        T: to be added
        A: A parameter
        Z: Positions of the source images

        """
        if isinstance(t_rho, tuple):
            mua = mua * 1e3 if self.mua is None else self.mua
            musp = musp * 1e3 if self.musp is None else self.musp
            anisothropy_coeff = anisothropy_coeff or self.anisothropy_coeff

            t = t_rho[0] * 1e-9
            rho = t_rho[1] * 1e-3
            s = self.s
            n1 = self.n1
            n2 = self.n2
            phantom = self.phantom  # noqa: F841
            DD = self.DD
            m = self.m
            eq = self.eq

            R_rho_t, T_rho_t = Reflectance_Transmittance_rho_t(
                rho, t, mua, musp, s, m, n1, n2, DD, eq, anisothropy_coeff, **kwargs
            )

            R_rho, T_rho = Reflectance_Transmittance_rho(
                rho, mua, musp, s, m, n1, n2, DD, eq
            )

            R_t, T_t = Reflectance_Transmittance_t(t, mua, musp, s, m, n1, n2, DD, eq)

            l_rho_R, l_rho_T = Mean_Path_T_R(rho, mua, musp, s, m, n1, n2, DD, eq)

            R, T = Reflectance_Transmittance(mua, musp, s, m, n1, n2, DD, eq)

            A = A_parameter(n1, n2)

            Z = Image_Sources_Positions(s, mua, musp, n1, n2, DD, m, eq)

            return (
                R_rho_t,
                T_rho_t,
                R_rho,
                T_rho,
                R_t,
                T_t,
                l_rho_R,
                l_rho_T,
                R,
                T,
                A,
                Z,
            )

        else:
            R_rho_t = []
            T_rho_t = []
            R_rho = []
            T_rho = []
            R_t = []
            T_t = []
            l_rho_R = []
            l_rho_T = []
            R = []
            T = []
            A = []
            Z = []
            mua = mua * 1e3 if self.mua is None else self.mua
            musp = musp * 1e3 if self.musp is None else self.musp
            anisothropy_coeff = anisothropy_coeff or self.anisothropy_coeff

            for value in t_rho:
                t = value[0] * 1e-9
                rho = value[1] * 1e-3
                s = self.s
                n1 = self.n1
                n2 = self.n2
                phantom = self.phantom  # noqa: F841
                DD = self.DD
                m = self.m
                eq = self.eq

                R_rho_t_, T_rho_t_ = Reflectance_Transmittance_rho_t(
                    rho, t, mua, musp, s, m, n1, n2, DD, eq, anisothropy_coeff
                )
                R_rho_t.append(R_rho_t_)
                T_rho_t.append(T_rho_t_)

                R_rho_, T_rho_ = Reflectance_Transmittance_rho(
                    rho, mua, musp, s, m, n1, n2, DD, eq
                )
                R_rho.append(R_rho_)
                T_rho.append(T_rho_)

                R_t_, T_t_ = Reflectance_Transmittance_t(
                    t, mua, musp, s, m, n1, n2, DD, eq
                )
                R_t.append(R_t_)
                T_t.append(T_t_)

                l_rho_R_, l_rho_T_ = Mean_Path_T_R(rho, mua, musp, s, m, n1, n2, DD, eq)
                l_rho_R.append(l_rho_R_)
                l_rho_T.append(l_rho_T_)

                R_, T_ = Reflectance_Transmittance(mua, musp, s, m, n1, n2, DD, eq)
                R.append(R_)
                T.append(T_)

                A_ = A_parameter(n1, n2)
                A.append(A_)

                Z_ = Image_Sources_Positions(s, mua, musp, n1, n2, DD, m, eq)
                Z.append(Z_)

            return (
                R_rho_t,
                T_rho_t,
                R_rho,
                T_rho,
                R_t,
                T_t,
                l_rho_R,
                l_rho_T,
                R,
                T,
                A,
                Z,
            )

    def _fit(
        self,
        t_rho_array_like: List[Tuple[float, float]],
        *args: Any,
        values_to_fit: Union[List[str], Any] = ["R_rho_t"],
        free_params: Union[List[str], Any] = ["musp"],
        **kwargs: Any,
    ) -> Union[float, int, None, List[float], Dict[Any, Any]]:
        """
        The call method returning the function used for scipy.curve_fit().

        :param t_rho_array_like: Variables of the model in the form List[(time, radial_coordinate), ...], passed as xdata to scipy.curve_fit(f, ydata, xdata, params).
        :type t_rho_array_like: List[Tuple[float, float]]
        :param mua: Absorption coefficient of the slab in [mm^-1]. Default: None.
        :param args: An iterable of the free_parameters for fitting in the order (mua, musp). The parameters have to match the free_params param. Anisothropy_coeff to be added.
        :type args: Any
        :param values_to_fit: Values passed to scipy.curve_fit(f, ydata, xdata, params) as ydata.
        :type values_to_fit: Union[List[str], Any]
        :param free_params: A list of free parameters passed down to scipy.curve_fit(f, ydata, xdata, params) as params for fitting.
        :type free_params: Union[List[str], Any]
        :param kwargs: Optional kwargs:
                       mode: available values: "approx", "sum"- controls G_function's computation method.
                       kwargs supported by the scipy.curve_fit() method
        :type kwargs: Any

        Returns:
        A dictionary with keys as passed in the values_to_fit param or a Union[float, List[float]] if a single value was provided.

        """

        available_values = [
            "R_rho_t",
            "T_rho_t",
            "R_rho",
            "T_rho",
            "R_t",
            "T_t",
            "l_rho_R",
            "l_rho_T",
            "R",
            "T",
            "A",
            "Z",
        ]
        available_free_params = ["mua", "musp"]

        if not all([param in available_free_params for param in free_params]):
            raise ValueError(
                f"Obtained params: {free_params} not in the list of params available for fitting."
            )

        if not all([value in available_values for value in values_to_fit]):
            raise ValueError(
                f"Obtained values: {values_to_fit} not in the list of values available for fitting."
            )

        ret: Union[Dict[Any, Any], Any] = None
        args_list = list(args)

        for param_index, param in enumerate(available_free_params):
            if param not in free_params:
                param_value = self.mua if param_index == 0 else self.musp
                args_list.insert(param_index, param_value)

        args = tuple(args_list)

        value: Any

        if isinstance(values_to_fit, list) and len(values_to_fit) > 1:
            ret = {}
            for value in values_to_fit:
                index = int(values_to_fit.index(str(value)))
                ret[value] = self(t_rho_array_like, *args, **kwargs)[index]

            return ret

        elif isinstance(values_to_fit, list) and len(values_to_fit) == 1:
            for value in values_to_fit:
                index = int(available_values.index(str(value)))
                ret = self(t_rho_array_like, *args, **kwargs)[index]

            return ret

        elif isinstance(values_to_fit, str):
            index = available_values.index(values_to_fit)
            ret = self(t_rho_array_like, *args, **kwargs)[index]

            return ret

        else:
            return None

    def fit(
        self, _t_rho_array_like: List[Tuple[float, float]], *args: Any, **kwargs: Any
    ) -> Tuple[List[float], ...]:
        """
        Method used to fit the model by Contini to existing data.

        :param _t_rho_array_like: An array-like input with tuples of the form (time, radial_coordinate), xdata.
        :type _t_rho_array_like: List[Tuple[float, float]]
        :param args: A tuple of free parameters for fitting.
        :type args: Any
        :param kwargs: Supports kwargs of the scipy.curve_fit() as well as mode: "approx", "sum" of the G_function().
        :type kwargs: Any

        Returns:
        popt: Values of the free parameters obtained after the function has been fit to the data.
        pcov: Covariance matrix of the output popt.

        """
        popt, pcov, *_ = curve_fit(self._fit, _t_rho_array_like, *args, **kwargs)
        return popt, pcov
